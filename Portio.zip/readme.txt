Resources and licenses :
img/profile.jpg - http://blacklistedphotos.blogspot.in/
img/gallery/  - http://urdunews.wordpress.com/page/15/
img/gallery/item.jpg - http://blog.karachicorner.com/2012/07/100-well-design-3d-character-illustrations/
