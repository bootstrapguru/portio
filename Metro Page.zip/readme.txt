****************First of all thanks for purchasing Metro Page******************

*****Installation******* 
1. Place all the files in the root folder of your website.
 
*******To Change Theme (its easy, give a try) *************
 1. Open main.less file in less folder 
 2. Goto last line of the page and then change theme to set your desired theme.
 
******** Enable or Disable header background *****************
change the following line from 
	background:url(../img/header.jpg);  /*enabled header background*/
to
	/*	background:url(../img/header.jpg);  disabled header background*/
	
	
Credits:
- Header background  http://www.freebiesbug.com/psd-freebies/30-hand-drawn-icons/
- Social icons  http://www.medialoot.com
- Responsive show case http:///www.pixeden.com
